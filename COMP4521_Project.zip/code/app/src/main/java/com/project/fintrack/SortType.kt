package com.project.fintrack

enum class SortType {
    USERNAME,
    PASSWORD,
    EMAIL
}